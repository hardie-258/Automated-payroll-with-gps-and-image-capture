The main theme of this paper is tracking the employee using an android device and calculating payroll
for the working hours he worked. From olden days there are many methods for evaluating the attendance, for example,
paper and pen method in this method either the supervisor will take the attendance or under his control, the
workers used to sing with their names, but this process had many backlogs and many proxies can be generated. Later
on the technology developed to great extent in the similar way the way of taking attendance also developed a lot for
example in current days they are using RFID chips, biometric devices, etc. but each of the methods is having a same or
different backlogs to eradicate the disadvantages and for accurate result we are introducing attendance method using
GPS tracking. Now a day’s people or any organization wants their work to be completed fast without taking any time
one of the examples payroll allotment so we also include a module for paying payroll according to the number of
days that they worked. This project contains two phases one is the mobile phase i.e. android app for field workers for
tracking their position for every 5 minutes and there is a web phase where the HR and admin will monitor the
employees and for security purpose they are allotted with the employee identification number and password and in the
web phase the tracking is done under the control of HR and admin. 
